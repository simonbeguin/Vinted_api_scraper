class Urls:

    VINTED_API_URL = f"https://www.vinted.fr/api/v2"
    VINTED_PRODUCTS_ENDPOINT = "catalog/items"
